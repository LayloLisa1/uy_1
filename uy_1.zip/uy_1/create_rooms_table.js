exports.up = function(knex) {
    return knex.schema.createTable('rooms', function(table) {
      table.increments('id').primary();
      table.string('name').notNullable();
      table.integer('floor').notNullable();
      table.integer('seats').notNullable();
    });
  };
  
  exports.down = function(knex) {
    return knex.schema.dropTable('rooms');
  };
  